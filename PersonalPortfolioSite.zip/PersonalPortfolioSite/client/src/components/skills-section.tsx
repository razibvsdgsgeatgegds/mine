import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import {
  SiReact,
  SiNodedotjs,
  SiPython,
  SiPhp,
  SiWordpress,
  SiHtml5,
  SiCss3,
  SiJavascript,
  SiGithub
} from "react-icons/si";

const skills = [
  { icon: SiReact, name: "React.js" },
  { icon: SiNodedotjs, name: "Node.js" },
  { icon: SiPython, name: "Python" },
  { icon: SiPhp, name: "PHP" },
  { icon: SiWordpress, name: "WordPress" },
  { icon: SiHtml5, name: "HTML5" },
  { icon: SiCss3, name: "CSS3" },
  { icon: SiJavascript, name: "JavaScript" },
  { icon: SiGithub, name: "GitHub" }
];

export default function SkillsSection() {
  return (
    <section id="skills" className="py-16 md:py-24">
      <div className="container px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Skills</h2>
          <div className="w-20 h-1 bg-primary mx-auto"></div>
        </motion.div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="transform hover:scale-105 transition-transform duration-300"
            >
              <Card className="h-full hover:border-primary/50 transition-colors">
                <CardContent className="p-6 flex flex-col items-center justify-center text-center">
                  <skill.icon className="w-12 h-12 mb-4 text-primary" />
                  <h3 className="text-lg font-medium">{skill.name}</h3>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}