import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema } from "@shared/schema";
import { ZodError } from "zod";
import { sendContactNotification } from "./mail";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/contact", async (req, res) => {
    try {
      const data = insertContactSchema.parse(req.body);
      const message = await storage.createContactMessage(data);

      // Send email notification
      const emailSent = await sendContactNotification(
        data.name,
        data.email,
        data.message
      );

      res.status(200).json({ 
        message: emailSent 
          ? "Message sent successfully and notification sent" 
          : "Message saved but notification failed",
        data: message 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ 
          message: "Invalid input",
          errors: error.errors 
        });
      } else {
        console.error("Failed to process contact message:", error);
        res.status(500).json({ 
          message: "Failed to send message" 
        });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}