import { MailService } from '@sendgrid/mail';

if (!process.env.SENDGRID_API_KEY) {
  throw new Error("SENDGRID_API_KEY environment variable must be set");
}

const mailService = new MailService();
mailService.setApiKey(process.env.SENDGRID_API_KEY);

const ADMIN_EMAIL = "worldcoders17@gmail.com"; // Admin's email address

export async function sendContactNotification(name: string, email: string, message: string) {
  try {
    await mailService.send({
      to: ADMIN_EMAIL,
      from: ADMIN_EMAIL, // Must be verified sender in SendGrid
      subject: `New Contact Form Message from ${name}`,
      text: `
Name: ${name}
Email: ${email}
Message: ${message}
      `,
      html: `
<h2>New Contact Form Submission</h2>
<p><strong>From:</strong> ${name}</p>
<p><strong>Email:</strong> ${email}</p>
<p><strong>Message:</strong></p>
<p>${message}</p>
      `,
    });
    return true;
  } catch (error) {
    // Add more detailed error logging
    console.error('SendGrid email error:', error);
    if ('response' in error) {
      console.error('SendGrid response:', error.response?.body);
    }
    return false;
  }
}